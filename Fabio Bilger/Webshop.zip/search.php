<?php
// Verbindung zur Datenbank
$servername = "localhost";
$username = "admin";
$password = "haus44hund";
$dbname = "genshinwiki";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Suchbegriffe aus dem Formular abrufen
$search = $_GET['search'];

// Suchanfrage erstellen
$sql = "SELECT * FROM items WHERE name LIKE '%" . $search . "%' OR description LIKE '%" . $search . "%'";
$result = $conn->query($sql);

// Ergebnisse ausgeben
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    echo '<li>';
    echo '<h2>' . $row['name'] . '</h2>';
    echo '<p>' . $row['description'] . '</p>';
    echo '<img src="' . $row['image'] . '">';
    echo '</li>';
  }
} else {
  echo 'No results found';
}

